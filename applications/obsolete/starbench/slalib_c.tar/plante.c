/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void sbmplante(double qfoo,double qbar,double phi,int qbaz,
double Q0,double qfobar,double q1,double q2,double qfoobar,
double Q3,double q4,double qfOBAz,double*qfoobaz,double*
QQUUX,double*Q5,int*QFRED){double qdog[13];sbmel2ue(qfoo,
qbaz,Q0,qfobar,q1,q2,qfoobar,Q3,q4,qfOBAz,qdog,QFRED);if(!*
QFRED)sbmplantu(qfoo,qbar,phi,qdog,qfoobaz,QQUUX,Q5,QFRED);}
