/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void sbmaop(double qfoo,double qbar,double qbaz,double Q0,
double qfobar,double q1,double hm,double q2,double qfoobar,
double Q3,double q4,double rh,double wl,double tlr,double*
qfOBAz,double*qfoobaz,double*QQUUX,double*Q5,double*QFRED){
double qdog[14];sbmaoppa(qbaz,Q0,qfobar,q1,hm,q2,qfoobar,Q3,
q4,rh,wl,tlr,qdog);sbmaopqk(qfoo,qbar,qdog,qfOBAz,qfoobaz,
QQUUX,Q5,QFRED);}
