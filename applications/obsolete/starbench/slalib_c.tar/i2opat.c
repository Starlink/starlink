/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void sbmi2opat(double qfoo,IOpars*qbar){qbar->eral=sbmera(
0.0,qfoo)+qbar->along;}
