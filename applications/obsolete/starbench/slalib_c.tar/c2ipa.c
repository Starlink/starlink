/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void sbmc2ipa(double qfoo,double qbar,double qbaz,CIpars*Q0,
double*qfobar){double q1[2][3]={{0.0,0.0,0.0},{0.0,0.0,0.0}}
;sbmc2ipas(qfoo,q1,qbar,qbaz,Q0,qfobar);}
