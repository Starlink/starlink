/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
double sbmdat(double qfoo){if(qfoo>=53736.0)return 33.0;if(
qfoo>=51179.0)return 32.0;if(qfoo>=50630.0)return 31.0;if(
qfoo>=50083.0)return 30.0;if(qfoo>=49534.0)return 29.0;if(
qfoo>=49169.0)return 28.0;if(qfoo>=48804.0)return 27.0;if(
qfoo>=48257.0)return 26.0;if(qfoo>=47892.0)return 25.0;if(
qfoo>=47161.0)return 24.0;if(qfoo>=46247.0)return 23.0;if(
qfoo>=45516.0)return 22.0;if(qfoo>=45151.0)return 21.0;if(
qfoo>=44786.0)return 20.0;if(qfoo>=44239.0)return 19.0;if(
qfoo>=43874.0)return 18.0;if(qfoo>=43509.0)return 17.0;if(
qfoo>=43144.0)return 16.0;if(qfoo>=42778.0)return 15.0;if(
qfoo>=42413.0)return 14.0;if(qfoo>=42048.0)return 13.0;if(
qfoo>=41683.0)return 12.0;if(qfoo>=41499.0)return 11.0;if(
qfoo>=41317.0)return 10.0;if(qfoo>=39887.0)return 4.2131700+
(qfoo-39126.0)*0.002592;if(qfoo>=39126.0)return 4.3131700+(
qfoo-39126.0)*0.002592;if(qfoo>=39004.0)return 3.8401300+(
qfoo-38761.0)*0.001296;if(qfoo>=38942.0)return 3.7401300+(
qfoo-38761.0)*0.001296;if(qfoo>=38820.0)return 3.6401300+(
qfoo-38761.0)*0.001296;if(qfoo>=38761.0)return 3.5401300+(
qfoo-38761.0)*0.001296;if(qfoo>=38639.0)return 3.4401300+(
qfoo-38761.0)*0.001296;if(qfoo>=38486.0)return 3.3401300+(
qfoo-38761.0)*0.001296;if(qfoo>=38395.0)return 3.2401300+(
qfoo-38761.0)*0.001296;if(qfoo>=38334.0)return 1.9458580+(
qfoo-37665.0)*0.0011232;if(qfoo>=37665.0)return 1.8458580+(
qfoo-37665.0)*0.0011232;if(qfoo>=37512.0)return 1.3728180+(
qfoo-37300.0)*0.001296;if(qfoo>=37300.0)return 1.4228180+(
qfoo-37300.0)*0.001296;return 1.4178180+(qfoo-37300.0)*
0.001296;}
