/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
double sbmgst(double qfoo,double qbar,double qbaz){return 
sbmdranrm(sbmera(qbar,qbaz)-sbmeo(qfoo));}
