/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void sbmoap(char*qfoo,double qbar,double qbaz,double Q0,
double qfobar,double q1,double q2,double hm,double qfoobar,
double Q3,double q4,double qfOBAz,double rh,double wl,double
 tlr,double*qfoobaz,double*QQUUX){double Q5[14];sbmaoppa(Q0,
qfobar,q1,q2,hm,qfoobar,Q3,q4,qfOBAz,rh,wl,tlr,Q5);sbmoapqk(
qfoo,qbar,qbaz,Q5,qfoobaz,QQUUX);}
