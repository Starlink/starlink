/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void sbmcd2tf(int qfoo,float qbar,char*qbaz,int Q0[4]){
sbmdd2tf(qfoo,(double)qbar,qbaz,Q0);}
