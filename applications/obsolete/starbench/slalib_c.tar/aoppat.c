/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
void sbmaoppat(double qfoo,double qbar[14]){qbar[13]=sbmgmst
(qfoo)+qbar[12];}
