/*
** Copyright (C) 2005 P.T.Wallace.
** Use for profit prohibited - enquiries to ptw@tpsoft.demon.co.uk.
*/
#include "slalib.h"
#include "slamac.h"
double sbmepj2d(double qfoo){return 51544.5+(qfoo-2000.0)*
365.25;}
